# QUESTION NO-3
distance=100
left_cockroach=1
right_cockroach=2
left_side=(1*10)-2
current_speed_left=8/10
right_side=(2*5)-1
current_speed_right=9/5
relative_speed=(8/10)+(9/5)
meet_time=distance/relative_speed
distance_from_left=meet_time*current_speed_left
distance_from_right=meet_time*current_speed_right
total_time_left=distance/current_speed_left
total_time_right=distance/current_speed_right
print(f'Meeting time of both cockroaches (in seconds) : {meet_time:.2f} seconds')
print(f'Distance from left side cockroach (in meters): {distance_from_left:.2f}meters')
print(f'Distance from right side cockroach (in meters):{distance_from_right:.2f} meters')
print(f'Total time for left cockroach (in seconds):{total_time_left:.2f} seconds')
print(f'Total time for right cockroach (in seconds):{total_time_right:.2f} seconds')
