#Q-4
import urllib.request
url="https://docs.google.com/document/d/1fsMpR_Un2dKERA6wDKOUh9u58buDGQId4Sb6mp6JjOc/edit"
file=urllib.request.urlopen(url)
for line in file:
    decoded_line=line.decode("utf-8").strip()
    print(decoded_line)
