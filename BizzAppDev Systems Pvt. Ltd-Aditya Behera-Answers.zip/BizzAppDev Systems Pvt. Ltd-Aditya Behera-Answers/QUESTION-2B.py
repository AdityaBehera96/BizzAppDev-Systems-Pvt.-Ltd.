#this is the second part of program to read element of csv file....above part is to insertion of data inside the file...
import csv
def main():
    try:
        f=open("emp.csv","r")
        r=csv.reader(f)
        for row in r:
            print(row)
    except OSError:
        print("unable to read a csv file...")
    finally:
        f.close()
main()