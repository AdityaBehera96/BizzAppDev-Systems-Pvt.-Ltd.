import csv
def main():
    try:
        f=open("emp.csv","w",newline='')
        cw=csv.writer(f)
        cw.writerow(['Name','Birthdate','Salary'])
        cw.writerow(['Vijay','1997-11-02','48000'])
        cw.writerow(['Arun','1996-04-17','37000'])
        cw.writerow(['Prasad','1992-03-23','41500'])
        cw.writerow(['Vishakha','1994-08-16','52000'])
        cw.writerow(['Namrata','1993-04-05','72000'])
    except OSError:
        print("Unable to create a CSV file...")
    finally:
        f.close()
main()
