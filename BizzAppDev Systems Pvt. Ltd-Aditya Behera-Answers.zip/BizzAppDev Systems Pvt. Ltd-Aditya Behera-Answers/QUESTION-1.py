#Q-1
print("*"*40)
x=input("Enter a calculation :")
print("*"*40)
print("The result is :",eval(x))
print("*"*40)

